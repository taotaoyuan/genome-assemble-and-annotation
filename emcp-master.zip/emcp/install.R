options(repos="http://mirrors.tuna.tsinghua.edu.cn/CRAN/")
options(BioC_mirror="http://mirrors.tuna.tsinghua.edu.cn/bioconductor/")

if (!requireNamespace("tidyverse", quietly = TRUE)) {install.packages("tidyverse")}
if (!requireNamespace("argparser", quietly = TRUE)) {install.packages("argparser")}
if (!requireNamespace("seqinr", quietly = TRUE)) {install.packages("seqinr")}
if (!requireNamespace("formattable", quietly = TRUE)) {install.packages("formattable")}
if (!requireNamespace("pkgbuild", quietly = TRUE)) {install.packages("pkgbuild")}

if (!requireNamespace("AnnotationForge", quietly = TRUE)) {BiocManager::install("AnnotationForge")}
if (!requireNamespace("clusterProfiler", quietly = TRUE)) {BiocManager::install("clusterProfiler")}
